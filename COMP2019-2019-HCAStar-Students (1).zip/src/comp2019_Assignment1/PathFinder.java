package comp2019_Assignment1;


/**
 * This class finds the best path from a start location to the goal location given the map.
 * The entry point for your code is in method findPath().
 *
 * DO NOT MODIFY THE SIGNATURE OF EXISTING METHODS AND VARIABLES.
 * Otherwise, JUnit tests will fail and you will receive no credit for your code.
 * Of course, you can add additional methods and classes in your implementation.
 *
 */
public class PathFinder {

    private Location start;	   // start location
    private Location goal;        // goal location
    private RectangularMap map;   // the map
   
    public PathFinder(RectangularMap map, Location start, Location goal) {
        this.map = map;
        this.start = start;
        this.goal = goal;
    }

    public RectangularMap getMap() {
        return map;
    }

    public Location getStart() {
        return start;
    }

    public Location getGoal() {
        return goal;
    }

	/* DO NOT CHANGE THE CODE ABOVE */
    /* adding imports and variables is okay. */
    
    /* Question 1:
     * add your code below. 
     * you can add extra methods.
     */

    public Path findPath() {
        //
        //TODO Question1
        // Implement A* search that finds the best path from start to goal.
        // Return a Path object if a solution was found; return null otherwise.
        // Refer to the assignment specification for details about the desired path.


        // not yet implemented
        throw new UnsupportedOperationException();
    }

}
